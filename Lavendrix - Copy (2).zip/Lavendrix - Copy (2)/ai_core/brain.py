import re
from .memory_db import get_session, save_session


class LavendrixBrain:

    def __init__(self):
        pass

    # ---------------- CORE HELPERS ----------------

    def _extract_keywords(self, text):
        return re.findall(r'\b[a-zA-Z]{4,}\b', text.lower())

    def _compute_complexity(self, text):
        word_count = len(text.split())
        unique_words = len(set(text.split()))
        return round((unique_words / (word_count + 1)) * 10, 2)

    def _risk_weight(self, risk_level):
        risk_map = {"low": 3, "medium": 5, "high": 8}
        return risk_map.get(risk_level.lower(), 5)

    def _detect_capabilities(self, description):
        desc = description.lower()

        capabilities = []

        if "kyc" in desc:
            capabilities.append("kyc")

        if "fraud" in desc:
            capabilities.append("fraud")

        if "transaction" in desc or "payment" in desc:
            capabilities.append("transaction")

        if "load" in desc or "scale" in desc or "performance" in desc:
            capabilities.append("performance")

        if "auth" in desc or "login" in desc:
            capabilities.append("authentication")

        if "log" in desc or "audit" in desc:
            capabilities.append("logging")

        return capabilities

    def _build_tests_from_capabilities(self, feature, capabilities):

        functional = []
        negative = []
        edge = []

        for cap in capabilities:

            if cap == "kyc":
                functional.append("Validate identity verification workflow")
                negative.append("Test invalid KYC document submission")
                edge.append("Test partial KYC completion scenario")

            if cap == "fraud":
                functional.append("Validate fraud detection trigger accuracy")
                negative.append("Simulate suspicious transaction pattern")
                edge.append("Test high-frequency micro-transaction attack")

            if cap == "transaction":
                functional.append("Verify transaction integrity and balance update")
                negative.append("Test duplicate transaction attempt")
                edge.append("Validate transaction rollback on failure")

            if cap == "performance":
                functional.append("Validate system response under expected load")
                negative.append("Simulate load spike attack")
                edge.append("Stress test at 2x expected traffic")

            if cap == "authentication":
                functional.append("Validate secure login process")
                negative.append("Simulate brute-force login attempt")
                edge.append("Test session timeout behavior")

            if cap == "logging":
                functional.append("Verify audit log creation")
                negative.append("Test log tampering attempt")
                edge.append("Validate log persistence under system restart")

        # fallback if nothing detected
        if not functional:
            functional.append(f"Validate {feature} core workflow")
            negative.append("Test invalid input handling")
            edge.append("Boundary value testing")

        return functional, negative, edge

    # ---------------- INTELLIGENT TEST ENGINE ----------------

    def generate_testcases(self, session_id, industry, feature, description, risk_level):

        session = get_session(session_id)
        conversation_count = session.get("conversation_count", 0) + 1
        session["conversation_count"] = conversation_count

        complexity = self._compute_complexity(description)
        risk_score = self._risk_weight(risk_level)

        session["risk_history"].append(risk_score)
        session["complexity_history"].append(complexity)

        save_session(
            session_id,
            session["risk_history"],
            session["complexity_history"],
            session["project_context"],
            conversation_count,
            session.get("last_intent", "")
        )

        capabilities = self._detect_capabilities(description)

        functional, negative, edge = self._build_tests_from_capabilities(
            feature, capabilities
        )

        severity_level = "LOW"
        if risk_score >= 7:
            severity_level = "HIGH"
        elif risk_score >= 5:
            severity_level = "MEDIUM"

        release_readiness = max(50, 100 - (risk_score * 5) - complexity)

        return {
            "dashboard_metrics": {
                "industry": industry,
                "feature": feature,
                "risk_score": risk_score,
                "complexity_score": complexity,
                "risk_severity": severity_level,
                "detected_capabilities": capabilities,
                "release_readiness_score": round(release_readiness, 2)
            },
            "intelligent_test_strategy": {
                "functional_tests": functional,
                "negative_tests": negative,
                "edge_case_tests": edge
            }
        }